-- VOLCAR DATOS EN LA TABLA USUARIO --

INSERT INTO `usuario` VALUES ('i72cuped@uco.es', 'David Cuevas Perez', '1999/07/05', '2022/08/20');
INSERT INTO `usuario` VALUES ('i92chpem@uco.es', 'Miguel Angel Chacon Perez', '2001/10/12', '2022/10/27');
INSERT INTO `usuario` VALUES ('manuel@gmail.com', 'Manuel Jimenez Rodriguez', '1994/05/20', '2019/12/23');
INSERT INTO `usuario` VALUES ('antoniomj@hotmail.es', 'Antonio Montes Jurado', '2003/01/26', '2022/04/01');