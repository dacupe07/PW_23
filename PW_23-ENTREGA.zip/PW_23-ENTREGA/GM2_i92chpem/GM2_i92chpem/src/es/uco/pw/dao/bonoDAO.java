package es.uco.pw.dao;

import es.uco.pw.business.bono.bonoDTO;
import es.uco.pw.business.pista.dificultad;
import es.uco.pw.business.pista.pistaDTO;
import es.uco.pw.connection.DBConnection;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Properties;

public class bonoDAO
{
    private static bonoDAO instance = null;
    private bonoDTO bono;
    int status = 0;

    protected Properties sql;

    public bonoDAO(Properties sql)
    {
        this.sql = sql;
    }

    // FUNCIONES
    
    /**Metodo para disminuir el numero de sesiones disponibles en un bono
     * @param correo
     * @param tipo
     * @param sql Fichero properties con instrucciones SQL
     */
    
    public void disminuirSesionBono(String correo, String tipo, Properties sql) {
    	
    	try {
    		int sesionesAux;
    		
        	
        	bonoDTO newBono = obtenerBono(correo, tipo, sql);
        	
        	sesionesAux= newBono.getNumSesiones();
        	sesionesAux= sesionesAux-1;
        	
        	if(sesionesAux==0) {
        		eliminarBono(newBono.getIdBono(), sql);
        	}
        	else
        	{
        		newBono.setNumSesiones(sesionesAux);
        		modificarBono(newBono, sql);
        	}
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
    	
    }
    
    /**Funcion para existe un bono
     * @param IDbono
     * @param sql Fichero properties con instrucciones SQL
     */

    public boolean existeBono(int IDbono,Properties sql)
    {
        boolean bonoExist = false;
        try
        {
            DBConnection cn = new DBConnection();
            PreparedStatement ps=cn.conex.prepareStatement(sql.getProperty("existeBono"));
            ps.setInt(1, IDbono);
            ResultSet rs = ps.executeQuery();

            while(rs.next())
            {
            	int aux = rs.getInt("id");
            	if(IDbono==aux) {
            		bonoExist = true;
            	}
            	else
                {
                    bonoExist = false;
                }
                
            }
            cn.closeConnection();
            ps.close();
        }
        catch(Exception e)
        {
            System.err.println("Error: " + e);
        }
        return bonoExist;
    }
    
    
    /**Funcion para comprobar si el bono del usuario es valido
     * @param correo
     * @param tipo
     * @param sql Fichero properties con instrucciones SQL
     * @return bonoExist, que almacenará true si es valido, o false en caso contrario
     */

    
    public boolean tieneBonoValido(String correo, String tipo, Properties sql)
    {
        boolean bonoExist = false;
        try
        {
            DBConnection cn = new DBConnection();
            PreparedStatement ps=cn.conex.prepareStatement(sql.getProperty("tieneBonoTipo"));
            ps.setString(1, correo);
            ps.setString(2, tipo);
            ResultSet rs = ps.executeQuery();


            while(rs.next())
            {
            	String correoAux = rs.getString("usuario");
            	String tipoAux = rs.getString("tipo");
            	if(correo.equals(correoAux) && tipo.equals(tipoAux)) {
            		bonoExist = true;
            	}
            	else
                {
                    bonoExist = false;
                }
                
            }
            cn.closeConnection();
            ps.close();
        }
        catch(Exception e)
        {
            System.err.println("Error: " + e);
        }
        return bonoExist;
    }
    
    /**Funcion para crear bono
     * @param bono Objeto de bonoDTO
     * @param sql Fichero properties con instrucciones SQL
     * @return status
     */

    public int crearBono(bonoDTO bono,Properties sql)
    {

        int status=0;

        try {
            DBConnection cn = new DBConnection();
            PreparedStatement ps=cn.conex.prepareStatement(sql.getProperty("crearBono"));

            if(existeBono(bono.getIdBono(),sql)==false)
            {
                ps.setInt(1, bono.getIdBono());
                ps.setString(2, bono.getUsuario());
                ps.setInt(3, bono.getNumSesiones());
                ps.setString(4, bono.getTipoBono());
                ps.setDate(5, Date.valueOf(bono.getCaducidad()));

                status = ps.executeUpdate();
                cn.closeConnection();
                ps.close();

            }
            else {
                System.out.println("\nEl bono con id " + bono.getIdBono() + " ya existe en la BD.\n");
                cn.closeConnection();
                ps.close();

            }

        }

        catch(Exception e) {
            e.printStackTrace();
        }

        return status;
    }
    
    /**Funcion para listar los bonos
     * @param sql Fichero properties con instrucciones SQL
     * @return lista_bonos Lista de todos los bonos
     */

    public ArrayList<bonoDTO> listarBonos(Properties sql)
    {
        ArrayList<bonoDTO> lista_bonos = new ArrayList<bonoDTO>();

        try
        {
            DBConnection cn = new DBConnection();
            PreparedStatement ps=cn.conex.prepareStatement(sql.getProperty("listarBono"));
            ResultSet rs = ps.executeQuery();

            while(rs.next())
            {
                int Id_bono=rs.getInt("id_bono");
                String correo=rs.getString("correo_usuario");
                int num_sesiones=rs.getInt("num_sesiones");
                String tipo=rs.getString("tipo_bono");
                LocalDate caducidad=rs.getDate("caducidad").toInstant().atZone(ZoneId.systemDefault()).toLocalDate();

                lista_bonos.add(new bonoDTO(Id_bono,correo,num_sesiones,tipo,caducidad));
            }

            cn.closeConnection();
            ps.close();
        }
        catch (Exception e)
        {
            System.err.println(e);

        }
        return lista_bonos;
    }
    
    /**Funcion para eliminar un bono
     * @param id Identificador del bono
     * @param sql Fichero properties con instrucciones SQL
     * @return status
     * @throws SQLException
     */

    public int eliminarBono(int id,Properties sql) throws SQLException
    {
        int status=0;
        try
        {
            DBConnection cn = new DBConnection();
            PreparedStatement ps=cn.conex.prepareStatement(sql.getProperty("borrarBono"));
            ps.setInt(1, id);
            status = ps.executeUpdate();
            cn.conex.close();
            ps.close();
        }
        catch (Exception e)
        {
            System.err.println("ERROR: " + e);
        }
        return status;
    }
    
    /**Funcion para modificar un bono
     * @param newBono Objeto de bonoDTO
     * @param sql Fichero properties con instrucciones SQL
     */
    
    public void modificarBono(bonoDTO newBono, Properties sql) {
    	try
        {
    		
        	DBConnection cn = new DBConnection();
            String query = sql.getProperty("modificarBono");
            PreparedStatement ps = cn.conex.prepareStatement(query);
           
            
            ps.setInt(1, newBono.getIdBono());
            ps.setString(2, newBono.getUsuario());
            ps.setInt(3,newBono.getNumSesiones());
            ps.setString(4, newBono.getTipoBono());
            ps.setDate(5, Date.valueOf(newBono.getCaducidad()));
            ps.setInt(6, newBono.getIdBono());
           
            status = ps.executeUpdate();
            cn.conex.close();
            ps.close();
            
        }
        catch(Exception e)
        {
            System.err.println("Error: " + e);
        }
    }
    
    /**Funcion para obtener el bono de un usuario
     * @param nombre Objeto de bonoDTO
     * @param tipo
     * @param sql Fichero properties con instrucciones SQL
     * @return bono Devuelve el objeto bono de bonoDTO
     */
    
    public bonoDTO obtenerBono(String nombre, String tipo, Properties sql) {
    	bono = new bonoDTO();
        try
        {
        	DBConnection cn = new DBConnection();
            String query = sql.getProperty("tieneBonoTipo");

            PreparedStatement ps = cn.conex.prepareStatement(query);
            ps.setString(1, nombre);
            ps.setString(2, tipo);
            ResultSet rs = ps.executeQuery();

            while(rs.next())
            {
            	String correoAux = rs.getString("usuario");
            	String tipoAux = rs.getString("tipo");
            	
            	if(nombre.equals(correoAux) && tipo.equals(tipoAux)) {
            		
            		
            		bono.setIdBono(rs.getInt("id_bono"));
            		bono.setUsuario(rs.getString("usuario"));
            		bono.setTipoBono(tipo);
            		bono.setNumSesiones(rs.getInt("n_sesiones"));
            		String fechaAux = rs.getString("caducidad");
            		bono.setCaducidad(LocalDate.parse(fechaAux));
            	}
            }            
            cn.conex.close();
            ps.close();
        }
        catch(Exception e)
        {
            System.err.println("Error: " + e);
        }
    	return bono;
    }
    
    /**Funcion para comprobar si un usuario tiene un bono y es valido
     * @param correo
     * @param sql
     * @return bonoExist True si el usuario tiene bono y es valido, y en caso contrario, false
     * @throws SQLException
     */

    public boolean tieneBono(String correo,Properties sql)
    {
        boolean bonoExist=false;
        try
        {
            DBConnection cn = new DBConnection();
            PreparedStatement ps=cn.conex.prepareStatement(sql.getProperty("tieneBono"));
            ps.setString(1, correo);
            ResultSet rs = ps.executeQuery();


            if(rs.next())
            {
                if(rs.getInt("num_sesiones")>0 && rs.getDate("caducidad").toInstant().atZone(ZoneId.systemDefault()).toLocalDate().isAfter(LocalDate.now())) {
                    bonoExist=true; }
                else {
                    bonoExist=false;
                }
            }
            else
            {
                bonoExist=false;
            }
            cn.closeConnection();
            ps.close();
        }
        catch(Exception e)
        {
            System.err.println("Error: " + e);
        }
        return bonoExist;
    }
}
