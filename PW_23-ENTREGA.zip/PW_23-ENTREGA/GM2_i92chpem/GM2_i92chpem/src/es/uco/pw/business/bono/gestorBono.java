package es.uco.pw.business.bono;

import es.uco.pw.business.pista.pistaDTO;
import es.uco.pw.business.reserva.reservaDTO;
import es.uco.pw.dao.bonoDAO;
import es.uco.pw.dao.pistaDAO;
import es.uco.pw.dao.reservaDAO;
import es.uco.pw.dao.usuarioDAO;

import java.sql.Date;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Properties;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class gestorBono
{
    Properties sql;

    bonoDAO bono = new bonoDAO(sql);
    pistaDAO pista = new pistaDAO(sql);
    usuarioDAO usuario = new usuarioDAO(sql);
    reservaDAO reserva = new reservaDAO(sql);
    
    Scanner entrada = new Scanner(System.in);
    public gestorBono(Properties sql)
    {
        this.sql = sql;
        
    }
    

    // FUNCIONES
    /**Funcion para establecer el precio de la reserva de bono
     * @param duracion
     * @return precio
     */
    public float establecerPrecio(int duracion)
    {
        float precio = 0;

        if(duracion == 60)
        {
            precio = 20;
        }
        else if(duracion == 90)
        {
            precio = 30;
        }
        else if(duracion == 120)
        {
            precio = 40;
        }

        return precio ;
    }
    
    
    /**Metodo para verificar si un correo es valido
     * @param correo
     * @return mat.find() Metodo que devuelve true si coincide el patron, o false en caso contrario
     */
    
    public boolean verificarEmail(String correo)
    {

        //Pattern patron = Pattern.compile("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)@" + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)(\\.[A-Za-z]{2,})$");

        Pattern pattern = Pattern.compile("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
                        + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");

        Matcher mat = pattern.matcher(correo);
        return mat.find();

    }
    
    /**Funcion gestora para crear un bono en la base de datos
     * @param sql Fichero properties con instrucciones SQL
     */
    
    public void crearBono(Properties sql) 
    {
    	bonoDTO nuevoBono = new bonoDTO();

    	System.out.print("Introduce el correo del usuario titular del bono: ");
    	nuevoBono.correo_usuario = entrada.nextLine();
    	
    	if(verificarEmail(nuevoBono.correo_usuario)==true) 
    	{
    		if(usuario.existeUsuario(nuevoBono.getUsuario(), sql)){
    			
    			System.out.print("Introduce el tipo de bono que desea obtener (familiar / infantil / adultos): ");
            	nuevoBono.tipo_bono = entrada.nextLine();
            	if(bono.tieneBonoValido(nuevoBono.correo_usuario, nuevoBono.tipo_bono, sql)== false) {
            		
            		//Establecemos el numero de sesiones al máximo inicial
            		nuevoBono.num_sesiones = 5;
            		
            		//Establecemos la fecha de caducidad a un año despues de su creacion
            		LocalDate newDate = LocalDate.now();
            		nuevoBono.caducidad = newDate.plusYears(1);
            		
            		//Mandamos los datos al DAO para que los introduzca en la BBDD.
            		bono.crearBono(nuevoBono, sql);
            	}
            	else {
            		System.out.print("El usuario introducido ya tiene registrado un bono del tipo "+nuevoBono.tipo_bono+". \n");
            	}	
    		}
    		else {
    			System.out.print("El usuario introducido no esta registrado en la base de datos. Pruébe otra vez o registrese.\n");
   	         	crearBono(sql);
    		}
    	}
    	else
    	{
			 System.out.print("El correo introducido no tiene el formato correcto, intentelo de nuevo con el formato: \nusuario@dominio.com/es\n");
	         crearBono(sql);
    	}
    }
    
    /**Funcion gestora para hacer una reserva con bono
     * @param sql Fichero properties con instrucciones SQL
     * @throws SQLException
     */
    
    public void reservaBono(Properties sql) throws SQLException {
    	
    	pistaDTO datosPista = new pistaDTO();
    	reservaDTO nuevaReservaBono = new reservaDTO();
    	DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy/MM/dd");
    	float precioAux, descuento;
    	
    	System.out.print("Introduce el correo del usuario: ");
         nuevaReservaBono.setUsuario(entrada.nextLine());

        if(verificarEmail(nuevaReservaBono.getUsuario()) == true) 
        {
            if (usuario.existeUsuario(nuevaReservaBono.getUsuario(), sql)) 
            {
            	System.out.print("Introduce el tipo de reserva que desea realizar (infantil / familiar / adultos): ");
            	nuevaReservaBono.setTipo(entrada.nextLine());
            	
            	if(bono.tieneBonoValido(nuevaReservaBono.getUsuario(), nuevaReservaBono.getTipo(), sql)) {
            		 System.out.print("Introduce el nombre de la pista: ");
                     nuevaReservaBono.setPista(entrada.nextLine());
                     if (pista.existePista(nuevaReservaBono.getPista(), sql)) 
                     {
                    	 datosPista = pista.obtenerPista(nuevaReservaBono.getPista(), sql);
                    	 
                    	 if(datosPista.getDificultad().toString().equals(nuevaReservaBono.getTipo())) {
                    		 
                    		 System.out.print("Introduce la fecha de la reserva (YYYY/MM/DD): ");
                             nuevaReservaBono.setFecha(LocalDate.parse(entrada.nextLine(), fmt));

                             System.out.print("Introduce la duracion de la reserva (60 min / 90 min / 120 min): ");
                             nuevaReservaBono.setDuracion(entrada.nextInt());
                             entrada.nextLine();

                             System.out.print("Introduce la hora de la reserva (hh:mm): ");
                             nuevaReservaBono.setHora(entrada.nextLine());
                             
                             precioAux=establecerPrecio(nuevaReservaBono.getDuracion());
                             nuevaReservaBono.setPrecio((float) (precioAux*0.95));
                             
                             descuento= precioAux-nuevaReservaBono.getPrecio();
                             nuevaReservaBono.setDescuento(descuento);
                             
                             
                             bono.disminuirSesionBono(nuevaReservaBono.getUsuario(), nuevaReservaBono.getTipo(), sql);
                             
                             reserva.reservaIndividual(nuevaReservaBono, sql);
                             
                    	 }
                    	 else {
                    		 System.out.print("La dificultad de la pista no coincide con el tipo de reserva elegida. Pruebe de nuevo con otra pista.\n");
                    		 reservaBono(sql);
                    	 }
                     }
                     else
                     {
                    	 System.out.print("La pista elegida no existe. Inténtelo de nuevo con otra pista.");
                    	 reservaBono(sql);
                     }
            	}
            	else {
            		System.out.print("La especialidad de tu bono no coincide con el tipo de reserva deseada.\n");
            	}
            	
            }
            else 
            {
            	System.out.print("El usuario introducido no esta registrado en la base de datos. Pruébe otra vez o registrese.\n");
   	         	reservaBono(sql);
            }
        }
        else
        {
            System.out.print("El correo introducido no tiene el formato correcto, intentelo de nuevo con el formato: \nusuario@dominio.com/es\n");
            reservaBono(sql);
        }
    	
    }
    
}
