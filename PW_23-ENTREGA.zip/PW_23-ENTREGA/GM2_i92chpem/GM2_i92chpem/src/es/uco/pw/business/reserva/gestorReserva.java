package es.uco.pw.business.reserva;

import es.uco.pw.business.pista.pistaDTO;
import es.uco.pw.business.usuario.gestorUsuarios;
import es.uco.pw.dao.pistaDAO;
import es.uco.pw.dao.reservaDAO;
import es.uco.pw.dao.usuarioDAO;

import java.sql.SQLException;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Properties;
import java.util.Scanner;

public class gestorReserva
{
    Properties sql;

    reservaDAO reserva = new reservaDAO(sql);

    pistaDAO pista = new pistaDAO(sql);

    usuarioDAO usuario = new usuarioDAO(sql);

    gestorUsuarios GestorUsuario = new gestorUsuarios(sql);

    public gestorReserva(Properties sql)
    {
        this.sql = sql;
        reservaDAO reserva = new reservaDAO(this.sql);
    }

    // FUNCIONES

    /**Funcion gestora para hacer una reserva individual 
     * @param sql Fichero properties con instrucciones SQL
     * @throws SQLException
     */
    
    public void reservaIndividualBBDD(Properties sql) throws SQLException
    {
        Scanner sc = new Scanner(System.in);
        pistaDTO datosPista = new pistaDTO();
        reservaDTO newReserva = new reservaDTO();
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy/MM/dd");
        float precioAux, descuento;



        System.out.print("Introduce el correo del usuario: ");
        newReserva.setUsuario(sc.nextLine());

        if(GestorUsuario.verificar_Email(newReserva.getUsuario()) == true) {

            if (usuario.existeUsuario(newReserva.getUsuario(), sql)) {
                System.out.print("Introduce el nombre de la pista: ");
                newReserva.setPista(sc.nextLine());

                if (pista.existePista(newReserva.getPista(), sql)) {
                    System.out.print("Introduce el tipo de reserva (adultos / familiar / infantil): ");
                    newReserva.setTipo(sc.nextLine());
                    
                    datosPista = pista.obtenerPista(newReserva.getPista(), sql);
                    
                    if(datosPista.getDificultad().toString().equals(newReserva.getTipo())) 
                    {
                    	System.out.print("Introduce la fecha de la reserva (YYYY/MM/DD): ");
                        newReserva.setFecha(LocalDate.parse(sc.nextLine(), fmt));

                        System.out.print("Introduce la duracion de la reserva (60 min / 90 min / 120 min): ");
                        newReserva.setDuracion(sc.nextInt());
                        sc.nextLine();

                        System.out.print("Introduce la hora de la reserva (hh:mm): ");
                        newReserva.setHora(sc.nextLine());

                        if (reserva.comprobarAntiguedad(newReserva.getUsuario(), sql) == true) {
                        	precioAux = reserva.establecerPrecio(newReserva.getDuracion(), sql);
                            newReserva.setPrecio((float)(precioAux*0.90));
                            descuento= precioAux-newReserva.getPrecio();
                            newReserva.setDescuento(descuento);
                        } else {
                        	precioAux = reserva.establecerPrecio(newReserva.getDuracion(), sql);
                            newReserva.setPrecio(precioAux);
                            newReserva.setDescuento(0);
                        }   

                        reserva.reservaIndividual(newReserva, sql);
                    }
                    else {
                    	System.out.print("La dificultad de la pista no coincide con el tipo de reserva elegida. Pruebe de nuevo con otra pista.\n");
                    	reservaIndividualBBDD(sql);
                    }
                    
                    
                }
                else
                {
                	System.out.print("La pista elegida no existe. Inténtelo de nuevo con otra pista.");
                	reservaIndividualBBDD(sql);
                }
            }
            else
            {
            	System.out.print("El usuario introducido no esta registrado en la base de datos. Pruébe otra vez o registrese.\n");
            	reservaIndividualBBDD(sql);
            }
        }
        else
        {
            System.out.print("El correo introducido no tiene el formato correcto, intentelo de nuevo con el formato: \nusuario@dominio.com/es\n");
            reservaIndividualBBDD(sql);
        }
    }

    /**Funcion gestora para listar las reservas
     * @param sql Fichero properties con instrucciones SQL
     * @return lista_reservas String con una lista de informacion de las reservas hechas
     */

    public String listarReservasBBDD(Properties sql)
    {
        Scanner sc = new Scanner(System.in);
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy/MM/dd");

        System.out.print("Introduce la fecha de la reserva: ");
        LocalDate fecha = LocalDate.parse(sc.nextLine(), fmt);

        System.out.print("Introduce la pista: ");
        String pista = sc.nextLine();

        String reserva_list = "";

        ArrayList<reservaDTO> reservas = reserva.listarReservas(fecha, pista, sql);

        for(reservaDTO u: reservas)
        {
            reserva_list = reserva_list + u.toStringReserva() + "\n";
        }

        return reserva_list;
    }


    /**Funcion gestora para listar las reservas futuras
     * @param sql Fichero properties con instrucciones SQL
     * @return lista_reservas String con una lista de informacion de las reservas futuras
     */

    public String listarReservasFuturasBBDD(Properties sql)
    {
        Scanner sc = new Scanner(System.in);
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy/MM/dd");
        
        LocalDate fecha = LocalDate.now();

        System.out.print("Introduce la pista: ");
        String pista = sc.nextLine();

        String reserva_list = "";

        ArrayList<reservaDTO> reservas = reserva.listarReservasFuturas(fecha, pista, sql);

        for(reservaDTO u: reservas)
        {
            reserva_list = reserva_list + u.toStringReserva() + "\n";
        }

        return reserva_list;
    }

    
    /** Funcion gestora para borrar o cancelar una reserva
     * @param sql Fichero properties con instrucciones SQL
     * @throws ParseException
     * @throws SQLException
     */


    public void cancelarReservaBBDD(Properties sql) throws ParseException, SQLException {
        Scanner entrada = new Scanner(System.in);
        int idRes;

        System.out.print("Introduce la ID de la reserva: ");
        idRes = entrada.nextInt();
        entrada.nextLine();

        reserva.cancelarReserva(idRes, sql);
        System.out.println("\n--- RESERVA ELIMINADA CON EXITO ---\n");
    }


    /** Funcion gestora para actualizar una reserva
     * @param sql Fichero properties con instrucciones SQL
     * @throws ParseException
     * @throws SQLException
     */

    public void actualizarReservaBBDD(Properties sql) throws ParseException, SQLException {
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy/MM/dd");
        Scanner sc = new Scanner(System.in);
        pistaDTO datosPista = new pistaDTO();
        reservaDTO newReserva = new reservaDTO();
        float precioAux, descuento;
        int idRes;
        

        System.out.print("Introduce el ID de la reserva: ");
        idRes = sc.nextInt();
        newReserva.setIdReserva(idRes);
        sc.nextLine();

        if(reserva.existeReserva(idRes, sql) == true)
        {

            System.out.print("Introduce el correo del usuario: ");
            newReserva.setUsuario(sc.nextLine());

            if(GestorUsuario.verificar_Email(newReserva.getUsuario()) == true) {

                if (usuario.existeUsuario(newReserva.getUsuario(), sql) == true) {
                	System.out.print("Introduce el nombre de la pista: ");
                    newReserva.setPista(sc.nextLine());

                    if (pista.existePista(newReserva.getPista(), sql)) {
                        System.out.print("Introduce el tipo de reserva (adultos / familiar / infantil): ");
                        newReserva.setTipo(sc.nextLine());
                        
                        datosPista = pista.obtenerPista(newReserva.getPista(), sql);
                        
                        if(datosPista.getDificultad().toString().equals(newReserva.getTipo())) 
                        {
                        	System.out.print("Introduce la fecha de la reserva (YYYY/MM/DD): ");
                            newReserva.setFecha(LocalDate.parse(sc.nextLine(), fmt));

                            System.out.print("Introduce la duracion de la reserva (60 min / 90 min / 120 min): ");
                            newReserva.setDuracion(sc.nextInt());
                            sc.nextLine();

                            System.out.print("Introduce la hora de la reserva (hh:mm): ");
                            newReserva.setHora(sc.nextLine());

                            if (reserva.comprobarAntiguedad(newReserva.getUsuario(), sql) == true) {
                            	precioAux = reserva.establecerPrecio(newReserva.getDuracion(), sql);
                                newReserva.setPrecio((float)(precioAux*0.90));
                                descuento= precioAux-newReserva.getPrecio();
                                newReserva.setDescuento(descuento);
                            } else {
                            	precioAux = reserva.establecerPrecio(newReserva.getDuracion(), sql);
                                newReserva.setPrecio(precioAux);
                                newReserva.setDescuento(0);
                            }   

                            reserva.actualizarReserva(newReserva, sql);
                        }
                        else {
                        	System.out.print("La dificultad de la pista no coincide con el tipo de reserva elegida. Pruebe de nuevo con otra pista.\n");
                        	reservaIndividualBBDD(sql);
                        }
                        
                        
                    }
                    else
                    {
                    	System.out.print("La pista elegida no existe. Inténtelo de nuevo con otra pista.");
                    	reservaIndividualBBDD(sql);
                    }
                }
                else
                {
                	System.out.print("El usuario introducido no esta registrado en la BBDD.\n");
                    actualizarReservaBBDD(sql);
                }
            }
            else
            {
                System.out.print("El correo introducido no tiene el formato correcto, intentelo de nuevo con el formato: \nusuario@dominio.com/es\n");
                actualizarReservaBBDD(sql);
            }
        }
        else
        {
            String respuesta = "";
            System.out.print("La reserva introducida no existe, ¿Desea crearla? (S -> Si / N -> No): ");
            respuesta = sc.nextLine();

            if(respuesta == "S" || respuesta == "s")
            {
                reservaIndividualBBDD(sql);
            }
            else
            {
                System.out.print("Regresando al menu...");
            }
        }
    }
}

