package es.uco.pw.business.kart;

public enum estado
{
    disponible,
    reservado,
    mantenimiento;

    private estado()
    {

    }
}
