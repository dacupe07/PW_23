Al descomprimir el archivo, encontraremos 1 carpeta con el workspace de eclipse, 1 archivo pdf que corresponde al informe de la práctica y por último, este fichero README.

Ingresar en eclipse, la carpeta llamada GM2_i92chpem, para ver todo el código.

Dentro de esta carpeta, se encuentra tambien los ficheros config.properties y sql.propiertes, y también el ejecutable de este programa.

Para que el programa ejecute correctamente, debera hacerlo en un directorio donde se encuentren estos dos últimos ficheros properties.

(POR DEFECTO ESTA EL EJECUTABLE JUNTO A SUS FICHEROS, PERO A UN COMPAÑERO LE DIO PROBLEMAS Y TUVO QUE MOVER LOS 3 ARCHIVOS A OTRO DIRECTORIO, SE LO NOTIFICO POR SI LE OCURRIERA ALGO SIMILAR)

Finalmente, para evitar posibles errores de tratamiento de letras, evite usar la letra española 'ñ' si ejecuta el programa desde la terminal, desde eclipse trata la letra sin ningún problema.