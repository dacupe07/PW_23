package es.uco.pw.dao;

import es.uco.pw.business.reserva.reservaDTO;
import es.uco.pw.business.usuario.usuarioDTO;
import es.uco.pw.connection.DBConnection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Properties;

public class reservaDAO
{
    private static reservaDAO instance = null;
    private reservaDTO reserva;

    private usuarioDTO usuario;

    int status = 0;

    protected Properties sql;

    public reservaDAO(Properties sql)
    {
        this.sql = sql;
    }

    // FUNCIONES
    /**Funcion para establecer el precio de una reserva
     * @param duracion
     * @param sql Fichero properties con instrucciones SQL
     * @return precio
     */
    
    public float establecerPrecio(int duracion, Properties sql) throws SQLException
    {
        float precio = 0;

        if(duracion == 60)
        {
            precio = 20;
        }
        else if(duracion == 90)
        {
            precio = 30;
        }
        else if(duracion == 120)
        {
            precio = 40;
        }

        return precio;
    }
    
    /**Funcion para consultar la existencia de una reserva
     * @param idReserva
     * @param sql Fichero properties con instrucciones SQL
     * @return resertExist true si existe, false en caso contrario
     */

    public boolean existeReserva(int idReserva, Properties sql)
    {
        boolean resertExist = false;
        try
        {
            DBConnection cn = new DBConnection();
            String query = sql.getProperty("existeReserva");

            PreparedStatement ps = cn.conex.prepareStatement(query);
            ps.setInt(1, idReserva);
            ResultSet rs = ps.executeQuery();

            while(rs.next())
            {
            	int aux = rs.getInt("idReserva");
            	
            	if(idReserva == aux) {
            		resertExist = true;
            	}
            	else
                {
                    resertExist = false;
                }
                
            }
            cn.conex.close();
            ps.close();
        }
        catch(Exception e)
        {
            System.err.println("Error: " + e);
        }
        return resertExist;
    }

    /**Funcion que comprueba la antiguedad de un usuario
     * @param correo
     * @param sql Fichero properties con instrucciones SQL
     * @return control True si la antiguedad es mayor de 2 años, false en caso contrario
     * @throws SQLException
     */

    public boolean comprobarAntiguedad(String correo, Properties sql) throws SQLException
    {
        DBConnection cn = new DBConnection();

        boolean control = false;

        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy/MM/dd");
        String query = sql.getProperty("comprobarAntiguedad");

        PreparedStatement ps = cn.conex.prepareStatement(query);
        ps.setString(1, correo);
        ResultSet rs = ps.executeQuery();
        
        String fecha_aux;
        LocalDate fechaInscripcion;


        reserva = new reservaDTO();
        usuario = new usuarioDTO();
        try
        {
            while (rs.next())
            {
                fecha_aux = rs.getString("fecha_inscripcion");
                fechaInscripcion = LocalDate.parse(fecha_aux);
                usuario.setFechaInscripcion(fechaInscripcion);
            }

            LocalDate ahora = LocalDate.now();

            fechaInscripcion = usuario.getFechaInscripcion();

            Period periodo = Period.between(fechaInscripcion, ahora);
            int años = periodo.getYears();

            if (años >= 2)
            {
                control = true;
            }
            else
            {
                control = false;
            }

            ps.close();
            cn.conex.close();
        }
        catch(Exception e)
        {
            System.err.print("ERROR: " + e);
        }

        return control;
    }

    
    /**Funcion para crear una reserva individual en la base de datos
     * @param reserva
     * @param sql Fichero properties con instrucciones SQL
     * @throws SQLException
     */

    public void reservaIndividual(reservaDTO reserva, Properties sql) throws SQLException
    {
        DBConnection cn = new DBConnection();

        String query = sql.getProperty("reservaIndividual");

        PreparedStatement ps = cn.conex.prepareStatement(query);

        try
        {
            ps.setInt(1, reserva.getIdReserva());
            ps.setString(2,reserva.getTipo());
            ps.setFloat(3, reserva.getPrecio());
            ps.setInt(4, reserva.getDuracion());
            ps.setFloat(5, reserva.getDescuento());
            ps.setString(6, reserva.getHora());
            ps.setDate(7, java.sql.Date.valueOf(reserva.getFecha()));
            ps.setString(8, reserva.getUsuario());
            ps.setString(9, reserva.getPista());

            ps.executeUpdate();

            cn.conex.close();
        }
        catch(Exception e)
        {
            System.err.print("ERROR: " + e);
        }
    }

    /**Funcion para listar las reservas que hay en una fecha y para una pista
     * @param fecha
     * @param pista
     * @param sql Fichero properties con instrucciones SQL
     * @return lista_reservas Lista con las reservas que hay para una de las pistas
     */

    public ArrayList<reservaDTO> listarReservas(LocalDate fecha, String pista, Properties sql)
    {
        ArrayList<reservaDTO> lista_reservas = new ArrayList<reservaDTO>();

        try
        {
            DBConnection cn = new DBConnection();

            String query = sql.getProperty("listarReservas");

            PreparedStatement ps = cn.conex.prepareStatement(query);
            ps.setDate(1,java.sql.Date.valueOf(fecha));
            ps.setString(2,pista);
            ResultSet rs = ps.executeQuery();

            while(rs.next())
            {
                int idReserva = rs.getInt("idReserva");
                float precio = rs.getFloat("precio");
                int duracion = rs.getInt("duracion");
                float descuento = rs.getFloat("descuento");
                String hora = rs.getString("hora");
                String usuario = rs.getString("usuario");
                lista_reservas.add(new reservaDTO(idReserva, precio, duracion, descuento, hora, fecha, usuario, pista));
            }

            cn.conex.close();
            ps.close();
        }
        catch (Exception e)
        {
            System.err.println(e);

        }
        return lista_reservas;
    }

    /**Funcion que lista las reservas que hay despues de una fecha
     * @param fecha
     * @param pista
     * @param sql Fichero properties con instrucciones SQL
     * @return lista_reservas Lista con las reservas futuras
     */

    public ArrayList<reservaDTO> listarReservasFuturas(LocalDate fecha, String pista, Properties sql)
    {
        ArrayList<reservaDTO> lista_reservas = new ArrayList<reservaDTO>();

        try
        {
            DBConnection cn = new DBConnection();

            String query = sql.getProperty("listarReservasFuturas");

            PreparedStatement ps = cn.conex.prepareStatement(query);
            ps.setDate(1,java.sql.Date.valueOf(fecha));
            ps.setString(2,pista);
            ResultSet rs = ps.executeQuery();

            while(rs.next())
            {
                int idReserva = rs.getInt("idReserva");
                float precio = rs.getFloat("precio");
                int duracion = rs.getInt("duracion");
                float descuento = rs.getFloat("descuento");
                String hora = rs.getString("hora");
                String usuario = rs.getString("usuario");
                lista_reservas.add(new reservaDTO(idReserva, precio, duracion, descuento, hora, fecha, usuario, pista));
            }

            cn.conex.close();
            ps.close();
        }
        catch (Exception e)
        {
            System.err.println(e);

        }
        return lista_reservas;
    }

    /**Funcion para eliminar una reserva de la base de datos
     * @param idRes
     * @param sql Fichero properties con instrucciones SQL
     * @throws SQLException
     */

    public void cancelarReserva(int idRes, Properties sql) throws SQLException
    {
        try
        {
            DBConnection cn = new DBConnection();
            String query = sql.getProperty("cancelarReserva");
            PreparedStatement ps = cn.conex.prepareStatement(query);

            status = ps.executeUpdate();
            cn.conex.close();
        }
        catch (Exception e)
        {
            System.err.println("ERROR: " + e);
        }
    }

    /**Funcion para actualizar una reserva de la base de datos
     * @param reserva
     * @param sql Fichero properties con instrucciones SQL
     */

    public void actualizarReserva(reservaDTO reserva, Properties sql)
    {
        DBConnection cn = new DBConnection();
        System.out.print("ID: "+reserva.getIdReserva());
        try
        {
            String query = sql.getProperty("actualizarReserva");
            PreparedStatement ps = cn.conex.prepareStatement(query);

            ps.setInt(1, reserva.getIdReserva());
            ps.setString(2,reserva.getTipo());
            ps.setFloat(3, reserva.getPrecio());
            ps.setInt(4, reserva.getDuracion());
            ps.setFloat(5, reserva.getDescuento());
            ps.setString(6, reserva.getHora());
            ps.setDate(7, java.sql.Date.valueOf(reserva.getFecha()));
            ps.setString(8, reserva.getUsuario());
            ps.setString(9, reserva.getPista());
            ps.setInt(10,reserva.getIdReserva() );

            status = ps.executeUpdate();
            cn.conex.close();
            System.out.print("\n --- RESERVA ACTUALIZADA CON EXITO --- \n");
        }
        catch(Exception e)
        {
            System.out.println("ERROR: " + e);
        }
    }

}
