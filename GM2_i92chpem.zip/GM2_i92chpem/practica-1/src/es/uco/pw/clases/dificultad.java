package es.uco.pw.clases;

public enum dificultad 
{
	INFANTIL, FAMILIAR, ADULTOS;
}
