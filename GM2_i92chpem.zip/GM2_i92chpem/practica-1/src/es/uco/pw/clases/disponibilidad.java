package es.uco.pw.clases;

public enum disponibilidad 
{
	DISPONIBLE, RESERVADO, MANTENIMIENTO;
}