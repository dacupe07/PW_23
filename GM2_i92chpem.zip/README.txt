Para la ejecución de este programa, no se necesita la introducción de ningún parámetro inicial para la ejecución del programa.

Una vez ejecutado el programa, simplemente debemos de escoger una de las opciones (con el número indicado) para ejecutar las correspondientes funcionalidades.