package es.uco.pw.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.print.attribute.standard.DateTimeAtCompleted;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import es.uco.pw.business.kart.kartDTO;
import es.uco.pw.business.pista.dificultad;
import es.uco.pw.business.pista.pistaDTO;
import es.uco.pw.dao.kartDAO;
import es.uco.pw.dao.pistaDAO;



/**
 * Servlet implementation class registerControllerServlet
 */
@WebServlet("/creadorGeneralServlet")
public class creadorGeneralServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public creadorGeneralServlet() 
    {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		String BDdriver = getServletContext().getInitParameter("BDdriver");
		String BDurl = getServletContext().getInitParameter("BDurl");
		String BDuser = getServletContext().getInitParameter("BDuser");
		String BDpass = getServletContext().getInitParameter("BDpass");
		
		HttpSession session = request.getSession(true);
		
		String opc = request.getParameter("opc");

		if(opc.equalsIgnoreCase("pista"))
		{
			RequestDispatcher rd;
			rd = request.getRequestDispatcher("/mvc/view/register/crearPistaView.jsp");
			rd.forward(request, response);
		}
		else if(opc.equalsIgnoreCase("kart"))
		{
			RequestDispatcher rd;
			rd = request.getRequestDispatcher("/mvc/view/register/crearKartView.jsp");
			rd.forward(request, response);
		}
		else if(opc.equalsIgnoreCase("modkart"))
		{
			try 
			{
				kartDAO AdDao = new kartDAO(BDdriver, BDurl, BDuser, BDpass);
				
				ArrayList<kartDTO> listKart = AdDao.listarKarts();
				
				request.setAttribute("listaKarts", listKart);
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
			RequestDispatcher rd;
			rd = request.getRequestDispatcher("/mvc/view/register/listarKartView.jsp");
			rd.forward(request, response);
		}
		else if(opc.equalsIgnoreCase("modpis"))
		{
			try
			{
				pistaDAO AdDao= new pistaDAO(BDdriver, BDurl, BDuser, BDpass);
				
				ArrayList<pistaDTO> listPista = AdDao.listarPistas();
				
				request.setAttribute("listaPistas", listPista);
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
			RequestDispatcher rd;
			rd = request.getRequestDispatcher("/mvc/view/register/listarPistasView.jsp");
			rd.forward(request, response);
			}
		}
		

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		// TODO Auto-generated method stub
		doGet(request, response);		
		

	}
}
