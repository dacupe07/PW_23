package es.uco.pw.controller;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.Properties;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import es.uco.pw.dao.pistaDAO;

public class modificarEstadoPistaControllerServlet extends HttpServlet {
	
private static final long serialVersionUID = 1L;
	
	public modificarEstadoPistaControllerServlet()
	{
		super();
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		response.getWriter().append("Served at 1: ").append(request.getContextPath());
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		
		HttpSession session = request.getSession(true);
		
		String BDdriver = getServletContext().getInitParameter("BDdriver");
		String BDurl = getServletContext().getInitParameter("BDurl");
		String BDuser = getServletContext().getInitParameter("BDuser");
		String BDpass = getServletContext().getInitParameter("BDpass");
		String sql_prop = request.getServletContext().getInitParameter("sqlprop");
		InputStream ruta = new FileInputStream(sql_prop);
		Properties sql = new Properties();
		sql.load(ruta);
		
		if((session.getAttribute("correo") == null) || (session.getAttribute("correo") == "") || (session.getAttribute("rol").equals("cliente")) ) {
			
			request.getRequestDispatcher("/mvc/view/login/loginView.jsp").forward(request, response);
		}
		
		else {
			try {
				pistaDAO pista = new pistaDAO(BDdriver,BDurl,BDuser,BDpass);
				
				 String nombre = request.getParameter("nombre");
				 String estado=request.getParameter("estado");
				 
				 pista.modificarEstadoPista(nombre, estado, sql);
				 request.getRequestDispatcher("/mvc/view/perfil/perfilViewAdmin.jsp").forward(request, response);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		 
		}
	}
}
