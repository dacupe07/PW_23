package es.uco.pw.controller;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Properties;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import es.uco.pw.dao.reservaDAO;

import java.io.IOException;



public class cancelarReservaAdminControllerServlet extends HttpServlet  {
	
	private static final long serialVersionUID = 1L;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}
	
protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		
		HttpSession session = request.getSession(true);
		
		String BDdriver = getServletContext().getInitParameter("BDdriver");
		String BDurl = getServletContext().getInitParameter("BDurl");
		String BDuser = getServletContext().getInitParameter("BDuser");
		String BDpass = getServletContext().getInitParameter("BDpass");
		String sql_prop = request.getServletContext().getInitParameter("sqlprop");
		InputStream ruta = new FileInputStream(sql_prop);
		Properties sql = new Properties();
		sql.load(ruta);
		
		if((session.getAttribute("correo") == null) || (session.getAttribute("correo") == "") || (session.getAttribute("rol").equals("cliente")) ) {
			
			request.getRequestDispatcher("/mvc/view/login/loginView.jsp").forward(request, response);
		}
		
		else {
			try {
				reservaDAO reserva = new reservaDAO(BDdriver,BDurl,BDuser,BDpass);
				int id_reserva = Integer.parseInt(request.getParameter("id_reserva"));
				
				reserva.cancelarReserva(id_reserva, sql);
				request.getRequestDispatcher("/mvc/view/perfil/perfilViewAdmin.jsp").forward(request, response);
				
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}
