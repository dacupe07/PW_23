package es.uco.pw.controller;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.Properties;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import es.uco.pw.dao.kartDAO;
import es.uco.pw.dao.pistaDAO;

public class asociarKartPistaControllerServlet extends HttpServlet {
	
private static final long serialVersionUID = 1L;
	
	public asociarKartPistaControllerServlet()
	{
		super();
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		response.getWriter().append("Served at 1: ").append(request.getContextPath());
	}
	
protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		
		HttpSession session = request.getSession(true);
		
		String BDdriver = getServletContext().getInitParameter("BDdriver");
		String BDurl = getServletContext().getInitParameter("BDurl");
		String BDuser = getServletContext().getInitParameter("BDuser");
		String BDpass = getServletContext().getInitParameter("BDpass");
		String sql_prop = request.getServletContext().getInitParameter("sqlprop");
		InputStream ruta = new FileInputStream(sql_prop);
		Properties sql = new Properties();
		sql.load(ruta);
		
		if((session.getAttribute("correo") == null) || (session.getAttribute("correo") == "") || (session.getAttribute("rol").equals("cliente")) ) {
			
			request.getRequestDispatcher("/mvc/view/login/loginView.jsp").forward(request, response);
		}
		
		else {
			try {
				kartDAO kart = new kartDAO(BDdriver,BDurl,BDuser,BDpass);
				pistaDAO pista = new pistaDAO(BDdriver,BDurl,BDuser,BDpass);
				
				String nombre_pista = request.getParameter("nombre");
				int id_kart = Integer.parseInt(request.getParameter("id_kart"));
				 
				 if(kart.existeKart(id_kart,sql)==true) {
					 if(pista.existePista(nombre_pista, sql) == true)
			            {
			                kart.listaKartPista(id_kart, nombre_pista, sql);
							request.getRequestDispatcher("/mvc/view/perfil/perfilViewAdmin.jsp").forward(request, response);
			            }
					 else {
						request.getRequestDispatcher("/errors/errorCatcher.jsp").forward(request, response);
					 }
				 }
				 else {
					request.getRequestDispatcher("/errors/errorCatcher.jsp").forward(request, response);
				 }
			} catch (SQLException e) {
				e.printStackTrace();
			}
		 
		}
	}
}
