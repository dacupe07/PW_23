package es.uco.pw.business.pista;

public enum dificultad
{
    infantil,
    familiar,
    adultos;

    private dificultad()
    {

    }
}
