package es.uco.pw.dao;

import es.uco.pw.business.kart.estado;
import es.uco.pw.business.pista.dificultad;
import es.uco.pw.business.pista.pistaDTO;
import es.uco.pw.connection.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Properties;

public class pistaDAO
{
    private static pistaDAO instance = null;
    private static DBConnection con;
    private static Connection connection;
    private pistaDTO pista;
    int status = 0;

    protected Properties sql;
    
    public pistaDAO(String BDdriver, String BDurl, String BDuser, String BDpass) throws SQLException 
    {

		con = new DBConnection(BDdriver, BDurl, BDuser, BDpass);
	}

    public pistaDAO(Properties sql)
    {
        this.sql = sql;
    }

    // FUNCIONES

    public void crearPista(String nombre, String estado, dificultad Dificultad, int num_max, Properties sql) throws SQLException
    {
        con.DBConnection();
        connection = con.getJdbcConnection();
        try
        {
            String query = sql.getProperty("crearPista");
            PreparedStatement ps = connection.prepareStatement(query);

            ps.setString(1, nombre);
            ps.setString(2, estado);
            ps.setString(3, String.valueOf(Dificultad));
            ps.setInt(4, num_max);

            ps.executeUpdate();
            con.desconectar();;
        }
        catch(Exception e)
        {
            System.out.print("ERROR: "+ e);
        }
    }
    
    public void modificarEstadoPista(String nombre, String estado, Properties sql) throws SQLException
    {
        con.DBConnection();
        connection = con.getJdbcConnection();
        try
        {
            String query = sql.getProperty("modificarEstadoKart");
            PreparedStatement ps = connection.prepareStatement(query);
            
            ps.setString(1, estado);
            ps.setString(2, nombre);

            ps.executeUpdate();
            con.desconectar();
        }
        catch(Exception e)
        {
            System.out.print("ERROR: "+ e);
        }
    }


    public ArrayList<pistaDTO> listarPistasMantenimiento(Properties sql)
    {
        ArrayList<pistaDTO> lista_pistas = new ArrayList<pistaDTO>();

        try
        {
            con.DBConnection();
            connection = con.getJdbcConnection();
            String query = sql.getProperty("listarPistasMantenimiento");

            Statement st = connection.createStatement();
            ResultSet rs = st.executeQuery(query);

            while(rs.next())
            {
                String nombre = rs.getString("nombre");
                String estado = rs.getString("estado");
                dificultad Dificultad = dificultad.valueOf(rs.getString("dificultad"));
                int num_max = rs.getInt("num_max");
                lista_pistas.add(new pistaDTO(nombre, estado, Dificultad, num_max));
            }

            con.desconectar();
            st.close();
        }
        catch (Exception e)
        {
            System.err.println(e);

        }
        return lista_pistas;
    }



    public ArrayList<pistaDTO> listarPistasDisponibles(Properties sql)
    {
        ArrayList<pistaDTO> lista_pistas = new ArrayList<pistaDTO>();

        try
        {
            con.DBConnection();
            connection = con.getJdbcConnection();
            String query = sql.getProperty("listarPistasDisponibles");

            Statement st = connection.createStatement();
            ResultSet rs = st.executeQuery(query);

            while(rs.next())
            {
                String nombre = rs.getString("nombre");
                String estado = rs.getString("estado");
                dificultad Dificultad = dificultad.valueOf(rs.getString("dificultad"));
                int num_max = rs.getInt("num_max");
                lista_pistas.add(new pistaDTO(nombre, estado, Dificultad, num_max));
            }

            con.desconectar();
            st.close();
        }
        catch (Exception e)
        {
            System.err.println(e);

        }
        return lista_pistas;
    }



    public boolean existePista(String nombre, Properties sql)
    {
        boolean pistaExist = false;
        try
        {
            con.DBConnection();
            connection = con.getJdbcConnection();
            String query = sql.getProperty("existePista");

            Statement st = connection.createStatement();
            ResultSet rs = st.executeQuery(query);


            if(rs.next())
            {
                pistaExist = true;
            }
            else
            {
                pistaExist = false;
            }
            con.desconectar();
            st.close();
        }
        catch(Exception e)
        {
            System.err.println("Error: " + e);
        }
        return pistaExist;
    }
}
