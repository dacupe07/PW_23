package es.uco.pw.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import es.uco.pw.business.usuario.usuarioDTO;
import es.uco.pw.dao.usuarioDAO;



/**
 * Servlet implementation class registerControllerServlet
 */
@WebServlet("/registerControllerServlet")
public class registerControllerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public registerControllerServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
		response.setContentType("text/html");
		
		String BDdriver = getServletContext().getInitParameter("BDdriver");
		String BDurl = getServletContext().getInitParameter("BDurl");
		String BDuser = getServletContext().getInitParameter("BDuser");
		String BDpass = getServletContext().getInitParameter("BDpass");
		
		usuarioDTO u = new usuarioDTO();
		
		String nombre = request.getParameter("nombre");
		String apellidos = request.getParameter("apellidos");
		String correo = request.getParameter("correo");
		String password = request.getParameter("password");
		
		String[] fecha_nac = request.getParameter("fecha_nacimiento").split("-");
		String ano = fecha_nac[0];
		String mes = fecha_nac[1];
		String dia = fecha_nac[2];
		String fecha_nacimiento = dia + "-" + mes + "-" + ano;
		
		String coches = (String) request.getParameter("coches");
		String motos = (String) request.getParameter("motos");
		String animales = (String) request.getParameter("animales");
		String plantas = (String) request.getParameter("plantas");
		String tecnologia = (String) request.getParameter("tecnologia");
		String videojuegos = (String) request.getParameter("videojuegos");
		String musica = (String) request.getParameter("musica");
		String artes = (String) request.getParameter("artes");
		
		try 
		{
			usuarioDAO DatosDao = new usuarioDAO(BDdriver, BDurl, BDuser, BDpass);
			
			int registro = DatosDao.comprobarRegistro(correo);
			
			if(registro != 0) 
			{
				u.setNombre(nombre);
				u.setCorreo(correo);
				u.setPassowrd(password);
				
				
				DatosDao.save(u);
				DatosDao.save_info(u);
				
				RequestDispatcher rd;
				rd = request.getRequestDispatcher("/mvc/control/login/goLoginController.jsp");
				rd.forward(request, response);
			}else {
				RequestDispatcher rd;
				rd = request.getRequestDispatcher("/mvc/view/registro/registerViewFail.jsp");
				rd.forward(request, response);
			}
			
			
		}
		catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
