package es.uco.pw.business.usuario;

public class customerBean implements java.io.Serializable
{
	private static final long serialVersionUID = 1L;
	
	private String emailUser = "";
	
	public String getEmailUser()
	{
		return emailUser;
	}
	
	public void setEmailUser(String emailUser)
	{
		this.emailUser = emailUser;
	}
}