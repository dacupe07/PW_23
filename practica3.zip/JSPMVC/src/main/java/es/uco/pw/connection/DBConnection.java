package es.uco.pw.connection;

import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;




public class DBConnection
{
    public Connection conex;
    Properties config_propiedades = new Properties();
    InputStream config = null;


   public DBConnection(String url, String user, String pwd)
    {
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            conex=DriverManager.getConnection(url, user, pwd);
            System.out.println("La conexion a la base de datos se ha establecido con exito!");
        }
        catch(Exception e)
        {
            System.err.println("ERROR: " + e);
        }
    }

    public void closeConnection() throws SQLException {
        if(conex != null)
        {
            if(!conex.isClosed())
            {
                conex.close();
            }
        }
    }
}


