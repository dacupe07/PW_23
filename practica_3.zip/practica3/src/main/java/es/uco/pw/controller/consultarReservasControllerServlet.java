package es.uco.pw.controller;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.Date;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Properties;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import es.uco.pw.business.reserva.reservaDTO;
import es.uco.pw.dao.reservaDAO;

@WebServlet("/consultarReservasControllerServlet")
public class consultarReservasControllerServlet extends HttpServlet  {

	public consultarReservasControllerServlet() {
		super();
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		response.getWriter().append("Served at 1: ").append(request.getContextPath());
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		HttpSession session = request.getSession(true);
		
		ArrayList<reservaDTO> lista_reservas = new ArrayList<reservaDTO>();
		
		String BDdriver = getServletContext().getInitParameter("BDdriver");
		String BDurl = getServletContext().getInitParameter("BDurl");
		String BDuser = getServletContext().getInitParameter("BDuser");
		String BDpass = getServletContext().getInitParameter("BDpass");
		String sql_prop = request.getServletContext().getInitParameter("sqlprop");
		InputStream ruta = new FileInputStream(sql_prop);
		Properties sql = new Properties();
		sql.load(ruta);
	
			reservaDAO reserva;
			try {
				reserva = new reservaDAO(BDdriver,BDurl,BDuser,BDpass);
				
				LocalDate fecha1=Date.valueOf(request.getParameter("fecha1")).toLocalDate();
				LocalDate fecha2=Date.valueOf(request.getParameter("fecha1")).toLocalDate();
				String correo=(String) session.getAttribute("correo");
				lista_reservas=reserva.listarReservasFuturas(fecha1, fecha2,correo,sql);
				
				PrintWriter out = response.getWriter();
			    
			    out.println("<html>");
			    out.println("<head>");
			    out.println("<title>Lista de reservas</title>");
			    out.println("</head>");
			    out.println("<body>");
			    out.println("<h1>Lista de reservas</h1>");
			    out.println("<ul>");
			    
			    for (reservaDTO u : lista_reservas) {
			        out.println("<li>" + u.toString() + "</li>");
			    }
			    
			    out.println("</ul>");
			    out.println("<a href='mvc/view/perfil/perfilViewCliente.jsp'>Volver</a>\r\n");
			    out.println("</body>");
			    out.println("</html>");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		
	}

}
