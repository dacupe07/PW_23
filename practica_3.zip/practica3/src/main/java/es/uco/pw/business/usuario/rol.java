package es.uco.pw.business.usuario;

public enum rol
{
    administrador,
    cliente;

    private rol()
    {

    }
}